import os, sqlite3, secrets, json, re
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, abort, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE=Path(__file__).parent
DB=Path(os.environ.get('DATABASE_PATH',str(BASE/'aster.sqlite3')))
UPLOAD=Path(os.environ.get('UPLOAD_PATH',str(BASE/'static'/'uploads')))
UPLOAD.mkdir(parents=True,exist_ok=True)
DB.parent.mkdir(parents=True,exist_ok=True)
app=Flask(__name__,static_folder='static')
app.secret_key=os.environ.get('SECRET_KEY',secrets.token_hex(32))
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE','0')=='1',MAX_CONTENT_LENGTH=8*1024*1024)

def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c

def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT NOT NULL,description TEXT DEFAULT "",price INTEGER DEFAULT 0,stock INTEGER DEFAULT 0,image TEXT DEFAULT "",featured INTEGER DEFAULT 0,visible INTEGER DEFAULT 1)')
  c.execute('CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,product_id INTEGER,name TEXT NOT NULL,phone TEXT NOT NULL,details TEXT DEFAULT "",size TEXT DEFAULT "",style TEXT DEFAULT "",frame TEXT DEFAULT "",due_date TEXT DEFAULT "",status TEXT DEFAULT "در انتظار بررسی",quoted_price INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
  c.execute('CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT NOT NULL)')
  if not c.execute('SELECT COUNT(*) FROM products').fetchone()[0]:
   c.executemany('INSERT INTO products(title,category,description,stock,image) VALUES(?,?,?,?,?)', [('منظره آبرنگ — نمونه','نقاشی آبرنگ','نمونه نمایشی',0,'/static/assets/framing.jpeg'),('گل‌های آبرنگ — نمونه','آثار گیاهی و طبیعت','نمونه نمایشی',0,'/static/assets/about.jpeg'),('نقاشی سفارشی — نمونه','سفارش اختصاصی','نمونه نمایشی',0,'/static/assets/custom.jpeg'),('اثر قاب‌شده — نمونه','آثار قاب‌شده','نمونه نمایشی',0,'/static/assets/process.jpeg')])
  username=os.environ.get('ADMIN_USERNAME','').strip();password=os.environ.get('ADMIN_PASSWORD','')
  if username and len(password)>=12 and not c.execute('SELECT 1 FROM admins').fetchone():
   c.execute('INSERT INTO admins(username,password_hash) VALUES(?,?)',(username,generate_password_hash(password)))
init()

def csrf():
 if 'csrf' not in session:session['csrf']=secrets.token_urlsafe(32)
 return session['csrf']

def verify_csrf():
 if not secrets.compare_digest(request.headers.get('X-CSRF-Token','') or request.form.get('csrf',''),csrf()):abort(403)

def admin_only(fn):
 @wraps(fn)
 def inner(*args,**kwargs):
  if not session.get('admin'):return jsonify(error='ورود مدیر لازم است'),401
  return fn(*args,**kwargs)
 return inner

@app.get('/')
def home():return render_template('index.html')
@app.get('/admin')
def admin():return render_template('admin.html',csrf=csrf(),logged_in=bool(session.get('admin')))
@app.post('/admin/login')
def login():
 verify_csrf();u=request.form.get('username','');p=request.form.get('password','')
 with db() as c:r=c.execute('SELECT * FROM admins WHERE username=?',(u,)).fetchone()
 if not r or not check_password_hash(r['password_hash'],p):return render_template('admin.html',csrf=csrf(),logged_in=False,error='نام کاربری یا رمز عبور نادرست است'),401
 session.clear();session['admin']=r['id'];csrf();return redirect('/admin')
@app.post('/admin/logout')
def logout():verify_csrf();session.clear();return redirect('/admin')
@app.get('/api/products')
def products():
 with db() as c:rows=c.execute('SELECT * FROM products WHERE visible=1 ORDER BY id DESC').fetchall()
 return jsonify([dict(r) for r in rows])
@app.get('/api/admin/products')
@admin_only
def all_products():
 with db() as c:rows=c.execute('SELECT * FROM products ORDER BY id DESC').fetchall()
 return jsonify([dict(r) for r in rows])
@app.post('/api/admin/products')
@admin_only
def create_product():
 verify_csrf();d=request.get_json(silent=True) or {};title=str(d.get('title','')).strip();category=str(d.get('category','')).strip()
 if not title or not category:return jsonify(error='عنوان و دسته‌بندی الزامی است'),400
 try:price=int(d.get('price',0));stock=int(d.get('stock',0))
 except: return jsonify(error='قیمت یا موجودی نامعتبر است'),400
 if price<0 or stock<0:return jsonify(error='مقادیر منفی مجاز نیست'),400
 with db() as c:
  cur=c.execute('INSERT INTO products(title,category,description,price,stock,image) VALUES(?,?,?,?,?,?)',(title[:150],category[:100],str(d.get('description',''))[:2000],price,stock,str(d.get('image',''))[:300]));pid=cur.lastrowid
 return jsonify(id=pid),201
@app.patch('/api/admin/products/<int:pid>')
@admin_only
def update_product(pid):
 verify_csrf();d=request.get_json(silent=True) or {};allowed={'title','category','description','price','stock','image','visible','featured'};fields={k:v for k,v in d.items() if k in allowed}
 if not fields:return jsonify(error='داده‌ای ارسال نشده'),400
 for k in ('price','stock','visible','featured'):
  if k in fields:
   try:fields[k]=int(fields[k])
   except:return jsonify(error='مقدار نامعتبر'),400
   if fields[k]<0:return jsonify(error='مقدار منفی'),400
 for k in ('title','category','description','image'):
  if k in fields:fields[k]=str(fields[k])[:2000]
 with db() as c:c.execute('UPDATE products SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),pid))
 return jsonify(ok=True)
@app.delete('/api/admin/products/<int:pid>')
@admin_only
def delete_product(pid):
 verify_csrf()
 with db() as c:c.execute('DELETE FROM products WHERE id=?',(pid,))
 return jsonify(ok=True)
@app.post('/api/admin/upload')
@admin_only
def upload():
 verify_csrf();f=request.files.get('file')
 if not f:return jsonify(error='فایل انتخاب نشده'),400
 from PIL import Image,UnidentifiedImageError
 try:
  im=Image.open(f.stream);im.verify();f.stream.seek(0);im=Image.open(f.stream);im.thumbnail((1800,1800));im=im.convert('RGB')
 except (UnidentifiedImageError,OSError,ValueError):return jsonify(error='فایل تصویر معتبر نیست'),400
 name=secrets.token_hex(16)+'.jpg';im.save(UPLOAD/name,format='JPEG',quality=85)
 return jsonify(url='/static/uploads/'+name)
@app.post('/api/requests')
def create_request():
 verify_csrf();d=request.get_json(silent=True) or {};name=str(d.get('name','')).strip();phone=str(d.get('phone','')).strip();details=str(d.get('details','')).strip();kind=str(d.get('kind','custom'))
 if not name or not re.fullmatch(r'[+0-9\s\-()]{9,20}',phone) or not details:return jsonify(error='نام، شماره معتبر و توضیحات الزامی است'),400
 if kind not in ('custom','product'):return jsonify(error='نوع درخواست نامعتبر'),400
 with db() as c:
  cur=c.execute('INSERT INTO requests(kind,product_id,name,phone,details,size,style,frame,due_date) VALUES(?,?,?,?,?,?,?,?,?)',(kind,d.get('product_id'),name[:100],phone,details[:3000],str(d.get('size',''))[:100],str(d.get('style',''))[:100],str(d.get('frame',''))[:100],str(d.get('due_date',''))[:40]));rid=cur.lastrowid
 return jsonify(id=rid,message='درخواست ثبت شد؛ پرداخت پس از تأیید هزینه انجام می‌شود'),201
@app.get('/api/admin/requests')
@admin_only
def requests_list():
 with db() as c:rows=c.execute('SELECT * FROM requests ORDER BY id DESC').fetchall()
 return jsonify([dict(r) for r in rows])
@app.patch('/api/admin/requests/<int:rid>')
@admin_only
def update_request(rid):
 verify_csrf();d=request.get_json(silent=True) or {};status=str(d.get('status',''))
 allowed=['در انتظار بررسی','در انتظار تأیید مشتری','در انتظار پرداخت','پرداخت تأیید شد','در حال ساخت','آماده ارسال','ارسال شد','تکمیل شد','لغو شد']
 if status not in allowed:return jsonify(error='وضعیت نامعتبر'),400
 try:price=int(d['quoted_price']) if d.get('quoted_price') not in (None,'') else None
 except:return jsonify(error='مبلغ نامعتبر'),400
 if price is not None and price<0:return jsonify(error='مبلغ نامعتبر'),400
 with db() as c:c.execute('UPDATE requests SET status=?,quoted_price=? WHERE id=?',(status,price,rid))
 return jsonify(ok=True)
@app.get('/api/csrf')
def csrf_endpoint():return jsonify(token=csrf())
@app.get('/health')
def health():return jsonify(status='ok')
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
